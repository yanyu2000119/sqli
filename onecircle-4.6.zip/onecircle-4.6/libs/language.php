<?php
global $language;
$language_cn = array(
    "defaultAddr" => "云深不知处"
);

$language = $language_cn;
