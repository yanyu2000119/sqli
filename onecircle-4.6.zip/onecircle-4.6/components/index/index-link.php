<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
/**
 * 主页 显示 link
 */
?>
<div class="row">
    <div class="post-content-inner-link col-xl-12">
        <?php $this->content()?>
    </div>
</div>