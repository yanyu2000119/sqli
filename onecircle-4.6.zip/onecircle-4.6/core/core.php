<?php

/* 插件方法 */
require_once('factory.php');
require_once('short.php');