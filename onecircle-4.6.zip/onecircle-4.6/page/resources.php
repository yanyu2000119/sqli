<?php
/**
 * neighbor page
 */
$this->need('includes/header.php');
?>

<?php $this->need('includes/body-layout.php');?>
<div id="resource">
    <?php  $this->need('page/pcontent.php');?>
</div>
<?php  $this->need('includes/footer.php');?>
